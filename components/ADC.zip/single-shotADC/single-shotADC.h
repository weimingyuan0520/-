#ifndef __SHADC_H_
#define __SHADC_H

#include "esp_adc/adc_oneshot.h"

extern adc_oneshot_unit_handle_t adc_unit_handle ;

void adc_single_short_init(void);

#endif
